﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 键值对
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList list = new ArrayList();
            //ArrayList的一些方法
            //Remove RemoveAt RemoveRange Clear Insert InsertRange Reverse Sort
            int[] aa = {1,3};
            int[] bb = {5,6};
            double width = 0,height = 0;
            int num = 4;
            Hashtable[] ht = new Hashtable[num];
            for(int i = 0;i < num;i++)
            {
                width += 3;
                height += 2;
                ht[i] = new Hashtable();
                //if ((width+height)/2 < 3)
                //{
                //    num--;
                //    i--;
                //    continue;
                //}
                ht[i].Add("area", 12);
                ht[i].Add("row", 13);
                ht[i].Add("width", width);
                ht[i].Add("height", height);
               
            }
    

        }
    }
}

//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.IO;

//namespace ConsoleApplication1
//{
//    class Program
//    {
     
//    }
//}